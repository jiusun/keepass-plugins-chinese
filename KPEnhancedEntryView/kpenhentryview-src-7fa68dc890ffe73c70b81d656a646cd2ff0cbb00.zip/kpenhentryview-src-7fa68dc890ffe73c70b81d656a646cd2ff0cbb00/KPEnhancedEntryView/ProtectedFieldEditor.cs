﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using KeePass.App;
using KeePass.UI;
using KeePassLib.Security;

namespace KPEnhancedEntryView
{
	public partial class ProtectedFieldEditor : Control
	{
		public ProtectedFieldEditor()
        {
            InitializeComponent();

            mToggleHidden.Width = Properties.Resources.B17x05_3BlackDots.Width + DpiUtil.ScaleIntX(16);

            SecureTextBoxEx.InitEx(ref mTextBox);
            // Re-assert properties that may be lost due to imperfect property cloning in UiUtil.PerformOverride
            mTextBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            mTextBox.Margin = Padding.Empty;
            mTextBox.Multiline = true;
            mTextBox.WordWrap = false;

            FixColoredPasswordMargin(mTextBox);

            mTextBox.EnableProtection(mToggleHidden.Checked);
        }

        

        #region ColoredPassword support
        private static bool sColoredTextBoxFieldValid = false;
        private static PropertyInfo sColoredTextBoxField;

        /// <summary>
        /// If https://github.com/Rookiestyle/ColoredPassword is active, gets the ColoredTextBox control nested inside the <see cref="SecureTextBoxEx"/> control
		/// used for actually editing the text
        /// </summary>
        private static PropertyInfo GetColoredTextBoxField(SecureTextBoxEx textBox)
        {
			if (!sColoredTextBoxFieldValid)
			{
				try
				{
					sColoredTextBoxFieldValid = true;
					sColoredTextBoxField = textBox.GetType().GetProperty("ColoredTextBox", BindingFlags.Public | BindingFlags.Instance);
				}
				catch (Exception ex)
				{
					Debug.Fail("Error attempting to obtain ColoredTextBox field", ex.Message);
				}
			}
            return sColoredTextBoxField;
        }

        /// <summary>
        /// Remove unwanted padding if https://github.com/Rookiestyle/ColoredPassword is active
        /// </summary>
        private static void FixColoredPasswordMargin(SecureTextBoxEx textBox)
        {
            var coloredTextBoxProperty = GetColoredTextBoxField(textBox);

            if (coloredTextBoxProperty != null)
            {
                var coloredTextBox = coloredTextBoxProperty.GetValue(textBox) as Control;
                if (coloredTextBox != null)
                {
                    coloredTextBox.Margin = Padding.Empty;
                }
            }
        }
        #endregion

        protected override void Select(bool directed, bool forward)
		{
			base.Select(directed, forward);
			mTextBox.Select();
		}

		public override Size GetPreferredSize(Size proposedSize)
		{
			var size = mTextBox.GetPreferredSize(proposedSize);
			return new Size(size.Width + mToggleHidden.Width, size.Height);
		}

		public bool HidePassword
		{
			get { return mToggleHidden.Checked; }
			set { mToggleHidden.Checked = value; }
		}

		public ProtectedString Value
		{
			get { return mTextBox.TextEx; }
			set { mTextBox.TextEx = value; }
		}

		private void mToggleHidden_CheckedChanged(object sender, EventArgs e)
		{
			if (!mToggleHidden.Checked && !AppPolicy.Try(AppPolicyId.UnhidePasswords))
			{
				mToggleHidden.Checked = true;
				return;
			}
			mTextBox.EnableProtection(mToggleHidden.Checked);
		}
	}
}
